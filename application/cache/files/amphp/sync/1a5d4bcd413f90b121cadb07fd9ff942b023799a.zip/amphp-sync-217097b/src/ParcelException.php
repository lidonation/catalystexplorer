<?php declare(strict_types=1);

namespace Amp\Sync;

class ParcelException extends \Exception
{
}
