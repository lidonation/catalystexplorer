<?php declare(strict_types=1);

namespace Amp\Parallel\Worker\Internal;

/** @internal */
final class JobCancellation extends JobPacket
{
}
