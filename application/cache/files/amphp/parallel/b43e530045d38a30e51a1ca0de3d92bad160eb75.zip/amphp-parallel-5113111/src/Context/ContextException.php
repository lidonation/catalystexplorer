<?php declare(strict_types=1);

namespace Amp\Parallel\Context;

use Amp\Sync\ChannelException;

class ContextException extends ChannelException
{
}
