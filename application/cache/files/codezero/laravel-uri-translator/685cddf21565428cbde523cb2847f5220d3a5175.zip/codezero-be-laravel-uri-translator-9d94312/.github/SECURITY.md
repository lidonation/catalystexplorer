# Security Policy

If you discover any security related issues, please email ivan@codezero.be instead of using the issue tracker.
