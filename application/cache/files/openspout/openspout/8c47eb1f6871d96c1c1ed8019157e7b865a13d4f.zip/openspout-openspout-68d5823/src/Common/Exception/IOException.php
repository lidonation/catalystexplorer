<?php

declare(strict_types=1);

namespace OpenSpout\Common\Exception;

final class IOException extends OpenSpoutException {}
