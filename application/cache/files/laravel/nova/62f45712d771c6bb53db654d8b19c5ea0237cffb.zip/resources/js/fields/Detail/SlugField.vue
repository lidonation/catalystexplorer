<script>
import TextField from '@/fields/Detail/TextField'

export default {
  extends: TextField,
}
</script>
