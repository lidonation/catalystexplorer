<template>
  <p class="help-text">
    <slot />
  </p>
</template>
