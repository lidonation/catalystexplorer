<script>
import FileField from '@/fields/Detail/FileField'

export default {
  extends: FileField,
}
</script>
