<script>
import FileField from '@/fields/Index/FileField'

export default {
  extends: FileField,
}
</script>
