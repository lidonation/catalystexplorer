<template>
  <CustomError404 />
</template>

<script setup>
import Guest from '@/layouts/Guest'

defineOptions({
  name: 'Error404Page',
  layout: Guest,
})
</script>
