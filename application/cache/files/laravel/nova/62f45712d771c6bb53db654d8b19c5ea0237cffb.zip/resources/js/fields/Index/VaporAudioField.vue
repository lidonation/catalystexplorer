<script>
import AudioField from '@/fields/Index/AudioField'

export default {
  extends: AudioField,
}
</script>
