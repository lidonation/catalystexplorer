<template>
  <CustomAppError />
</template>

<script setup>
import Guest from '@/layouts/Guest'

defineOptions({
  name: 'AppErrorPage',
  layout: Guest,
})
</script>
