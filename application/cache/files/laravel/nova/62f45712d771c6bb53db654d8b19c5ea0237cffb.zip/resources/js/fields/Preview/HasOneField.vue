<script>
import HasOneField from '@/fields/Detail/HasOneField'

export default {
  extends: HasOneField,

  data: () => ({
    showActionDropdown: false,
  }),
}
</script>
