<template>
  <div>
    <slot />
  </div>
</template>

<script setup>
defineOptions({
  name: 'Guest',
})
</script>
