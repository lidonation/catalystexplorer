<template>
  <Icon
    class="shrink-0 text-gray-700 dark:text-gray-400"
    name="chevron-down"
    type="mini"
  />
</template>

<script setup>
import { Icon } from 'laravel-nova-ui'
</script>
