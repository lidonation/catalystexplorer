<script>
import AudioField from '@/fields/Detail/AudioField'

export default {
  extends: AudioField,
}
</script>
