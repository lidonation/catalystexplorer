<script>
import TextField from '@/fields/Index/TextField'

export default {
  extends: TextField,
}
</script>
