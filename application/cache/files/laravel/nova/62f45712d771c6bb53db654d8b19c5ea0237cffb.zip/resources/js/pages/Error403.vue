<template>
  <CustomError403 />
</template>

<script setup>
import Guest from '@/layouts/Guest'

defineOptions({
  name: 'Error403Page',
  layout: Guest,
})
</script>
