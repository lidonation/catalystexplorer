<template>
  <h3 class="mt-3 px-3 text-xs font-bold">
    <slot />
  </h3>
</template>
