window.LaravelNovaUi = require('./components/index')
