<?php

namespace Laravel\Horizon\Contracts;

interface Silenced
{
}
