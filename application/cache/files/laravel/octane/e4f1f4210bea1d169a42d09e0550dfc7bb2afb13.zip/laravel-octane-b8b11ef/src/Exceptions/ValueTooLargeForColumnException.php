<?php

namespace Laravel\Octane\Exceptions;

use InvalidArgumentException;

class ValueTooLargeForColumnException extends InvalidArgumentException
{
    // ..
}
