# Laravel Nova Enum Field
A Laravel Nova field for Enums from bensampo/laravel-enum.

## Installation

To use this package, you need a Laravel installation with [Nova](https://nova.laravel.com).

**Composer**

```bash
composer require simplesquid/nova-enum-field
```
