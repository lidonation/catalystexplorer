<?php

declare(strict_types=1);

namespace Saloon\Http\Faking;

/**
 * @method static static make(mixed $body = [], int $status = 200, array $headers = [])
 */
class MockResponse extends FakeResponse
{
    //
}
