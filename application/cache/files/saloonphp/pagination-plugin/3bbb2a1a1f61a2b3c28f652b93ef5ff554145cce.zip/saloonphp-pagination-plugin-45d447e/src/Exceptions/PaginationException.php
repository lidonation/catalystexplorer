<?php

declare(strict_types=1);

namespace Saloon\PaginationPlugin\Exceptions;

use Saloon\Exceptions\SaloonException;

class PaginationException extends SaloonException
{
    //
}
