<?php

declare(strict_types=1);

namespace Intervention\Gif\Exceptions;

class EncoderException extends \RuntimeException
{
}
