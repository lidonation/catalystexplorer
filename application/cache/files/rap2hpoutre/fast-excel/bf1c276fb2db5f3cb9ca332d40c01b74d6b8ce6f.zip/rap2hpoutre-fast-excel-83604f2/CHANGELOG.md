# 4.0.0
- Move from box/spout to openspout/openspout v3 | https://github.com/openspout/openspout
- Fix phpunit tests
- Add support to php 8.1
- Integrated with Github Actions
- Add auto dependabot merge


# 3.0.0
- add support for PHP 8
- update PHPUnit to 6.4 to 9.5
- update Spout from 2 to 3
- (breaking change) drop support for PHP 7.1
- (breaking change) remove setEndOfLineCharacter support for CSV
