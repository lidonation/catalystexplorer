<?php

declare(strict_types=1);

namespace MyNamespace;

enum MyEnumWithConstant
{
    public const MYCONST = 'MyConstValue';
}
