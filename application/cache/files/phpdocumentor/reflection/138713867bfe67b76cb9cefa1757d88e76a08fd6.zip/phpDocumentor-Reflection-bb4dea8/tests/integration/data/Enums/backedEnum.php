<?php

declare(strict_types=1);

namespace MyNamespace;

enum MyBackedEnum : string
{
    case VALUE1 = 'this is value1';
    case VALUE2 = 'this is value2';
}
