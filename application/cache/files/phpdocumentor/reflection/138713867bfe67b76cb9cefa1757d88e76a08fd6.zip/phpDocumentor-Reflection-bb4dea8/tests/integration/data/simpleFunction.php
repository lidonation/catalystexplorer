<?php

function simpleFunction(array $options = []): void
{
    return;
}

exit();
