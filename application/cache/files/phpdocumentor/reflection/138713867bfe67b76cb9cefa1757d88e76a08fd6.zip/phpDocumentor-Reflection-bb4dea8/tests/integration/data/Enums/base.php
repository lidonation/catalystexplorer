<?php

declare(strict_types=1);

namespace MyNamespace;

enum MyEnum
{
    case VALUE1;
    case VALUE2;
}
