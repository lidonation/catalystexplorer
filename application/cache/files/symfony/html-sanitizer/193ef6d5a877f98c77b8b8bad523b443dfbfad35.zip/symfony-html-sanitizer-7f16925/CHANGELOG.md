CHANGELOG
=========

6.4
---

 * Add support for sanitizing unlimited length of HTML document

6.1
---

 * Add the component as experimental
