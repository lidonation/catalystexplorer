<?php

declare(strict_types=1);

namespace Pest\Mutate\Exceptions;

use Exception;

class InvalidMutatorException extends Exception {}
