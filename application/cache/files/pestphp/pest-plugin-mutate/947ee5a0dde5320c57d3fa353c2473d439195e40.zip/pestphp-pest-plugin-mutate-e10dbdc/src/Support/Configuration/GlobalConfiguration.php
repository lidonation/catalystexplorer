<?php

declare(strict_types=1);

namespace Pest\Mutate\Support\Configuration;

class GlobalConfiguration extends AbstractConfiguration {}
