<?php

declare(strict_types=1);

namespace Meilisearch\Contracts;

use Meilisearch\Endpoints\Delegates\TasksQueryTrait;

class CancelTasksQuery
{
    use TasksQueryTrait;
}
