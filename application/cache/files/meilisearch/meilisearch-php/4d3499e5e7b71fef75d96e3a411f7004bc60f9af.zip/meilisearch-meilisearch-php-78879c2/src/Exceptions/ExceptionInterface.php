<?php

declare(strict_types=1);

namespace Meilisearch\Exceptions;

interface ExceptionInterface extends \Throwable
{
}
