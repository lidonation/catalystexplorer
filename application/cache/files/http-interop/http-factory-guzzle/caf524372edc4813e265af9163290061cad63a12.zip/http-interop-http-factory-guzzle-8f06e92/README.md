# HTTP Factory for Guzzle

HTTP factory implemented for [Guzzle](https://github.com/guzzle/psr7).

**NOTE:** `guzzlehttp/psr7` includes an HTTP factory implementation starting with
version 2.0. Please use the official factory if your project can use
`"guzzlehttp/psr7": "^2.0"`.
